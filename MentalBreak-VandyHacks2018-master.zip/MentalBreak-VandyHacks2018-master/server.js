var app = require('./server/config/app');
var server = app.start();